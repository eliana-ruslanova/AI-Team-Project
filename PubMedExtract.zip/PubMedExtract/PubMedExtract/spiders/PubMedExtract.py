import scrapy
import time
import pdb
import re
import json
import datetime

class PubMedExtract(scrapy.Spider):
    name = "PubMed"
    currentYear = 0
    
    #SearchEachYear
    def start_requests(self):
        url_search_blank = 'https://pubmed.ncbi.nlm.nih.gov/?term=Artificial%20Intelligence&filter=years.'
        
        currentTime = datetime.datetime.now()
        actualYear = int(currentTime.year)
        firstYear = int(actualYear) - 15
        for y in range(firstYear, actualYear+1):
            currentYear = y
            year = str(y)
            url_search = url_search_blank + year + '-' + year + '&page='
            yield scrapy.Request(url = url_search, meta={'currentYear': currentYear})
            
       
    #Extract Hits and generate number of pages - Then search on each page of the year 
    def parse(self, response):
        numberHits = response.css('div.results-amount span::text').get()
        numberHits = numberHits.replace(",", "")
        numberPages = int((int(numberHits)/10)+1)
        for x in range(1,numberPages):
            url = response.url + f'{x}'
            yield scrapy.Request(url = url, callback = self.parsePage, meta={'currentYear': response.meta['currentYear']})
        
    #Extract all PMIDs on one page
    def parsePage(self, response):
        url_article_blank = 'https://pubmed.ncbi.nlm.nih.gov/'
        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'DNT': '1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
            'Sec-Fetch-User': '?1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        
        for article in response.css('article.full-docsum'):
            currentDoc = article.css('.docsum-pmid::text').get()
            url_article = url_article_blank + currentDoc
            yield scrapy.Request(url = url_article, callback = self.parseDoi, meta={'currentYear': response.meta['currentYear']}, headers = headers)
            
    
    #Extract Doi and full text of one PMID 
    def parseDoi(self, response):
        doi = ""
        pmid = ""
        keywords = ""
        meshTerms = ""
        title = ""
        authors = ""
        journal = ""   
        volume = ""
        relatedArticles = ""
        abstract = []
        containsFullText = 0
        fullTexts = []
        count = 0
        abstractFinal = []
        
        #Extract Title
        title = response.css('div.full-view h1::text').get()
        title = re.sub('\\n\s{0,10}', '', title)
        title = re.sub('\s{3,10}', '', title)
        
        #Extract Authors
        for name in response.css('a.full-name::text').extract():
            if name not in authors:
                authors = authors + name + "; "
            
        
        #Extract DOI
        for span in response.css('span.identifier'):
            idLabel = span.css('.id-label::text').get()
            if 'DOI' in idLabel:
                doi = span.css('a.id-link::text').get()
            elif 'PMID' in idLabel:
                pmid = 'PMID:' + span.css('strong.current-id::text').get()
                
        doi = doi.replace("\n", "")
        doi = doi.replace(" ", "")
        pmid = pmid.replace("\n", "")
        pmid = pmid.replace(" ", "")
        pmid = pmid.replace("PMID:", "")
        
        journal = response.xpath('//*[@name="citation_publisher"]/@content').extract()
        volume = response.xpath('//*[@name="citation_volume"]/@content').extract()
        
        for li in response.css('.full-docsum'):
            if relatedArticles == "":
                relatedArticles = li.css('.docsum-pmid::text').get()
            else:
                relatedArticles = relatedArticles + "," + li.css('.docsum-pmid::text').get()
        
        #Check for full text 
        for div in response.css('div.inner-wrap'):
            if 'full-text-links' in div.css('div').get():
                containsFullText = 1

        if containsFullText == 1:
            for a in response.css('div.full-text-links-list a'):
                if a.css('::attr(href)').get() not in fullTexts:
                    fullTexts.append(a.css('::attr(href)').get())
        else:
            fullTexts.append("None")
        
        print("------------------------------------------------------")
        #Extract Abstract
        if 'abstract' in response.css('main.article-details').get():
            for p in response.css('div.abstract-content p').extract():
                abstract.append(p)
                
        for string in abstract:
            string = string.replace("<p>", "")
            string = string.replace("</p>", "")
            string = string.replace('<strong class="sub-title">', '')
            string = string.replace('</strong>', '')
            string = re.sub('\s{2,20}', ' ', string)
            string = string.replace("\n", "")
            abstractFinal.append(string)
        
        if 'abstract' in response.css('main.article-details').get():
            for p in response.css('div.abstract').extract():
                if "Keyword" in p:
                    keywords = p
         
        #Extract Keywords
        keywords = keywords.replace("\n", "")
        keywords = re.sub('.+Keywords:.+</strong>\s{2,20}', '  ', keywords)
        keywords = re.sub('\.\s{2,20}.+</div>', '; ', keywords)
        
        if 'mesh-terms' in response.css('main.article-details').get():
            for li in response.css('ul.keywords-list li'):
                for stringButton in li.css('button::text').extract():
                    meshTerms = meshTerms + stringButton + ";  "
            
        meshTerms = re.sub('\\n\s{2,7}', '', meshTerms)
        
        abstractMerged = ""
        fullTextsMerged = ""
        for abst in abstractFinal:
            abstractMerged = abstractMerged + abst
        for fulltxt in fullTexts:
            fullTextsMerged = fullTextsMerged + fulltxt + "; " 
        keywordsMerged = keywords + "  " + meshTerms
        
        # Data to be written 
        dictionary ={ 
            "Title" : title,
            "Authors" : authors,
            "Year" : response.meta['currentYear'],
            "Doi" : doi, 
            "PMID" : pmid,
            "Journal" : journal[0],
            "Volume" : volume[0],
            "Abstract" : abstractMerged, 
            "Keywords_Abstract" : keywords,
            "Keywords_MeSH" : meshTerms,
            "Keywords_Merged" : keywordsMerged,
            "FullTextLinks" : fullTexts,
            "Related Articles" : relatedArticles
        } 
  
        # Serializing json  
        json_object = json.dumps(dictionary, indent = 4) 
        
        fileTime = datetime.datetime.now()
        fileYear = str(fileTime.year)
        
        # Writing to sample.json 
        filename = 'extractUntil' + fileYear + '.json'
        with open(filename, "a") as outfile:
            #json.dump(dictionary, outfile, indent = 4)
            outfile.write(json_object) 
            outfile.write(",")
    
            
